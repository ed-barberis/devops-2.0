# Copyright (c) 2015 Oracle and/or its affiliates. All rights reserved.
# created by abhijit.jere

import requests
import json
import logging 
from collections import OrderedDict
try:
    from handlers import RequestParamHandler, ResponseHandler
    from utils import Utils
    from messages import Messages, ErrorMessages
except:
    from .handlers import RequestParamHandler, ResponseHandler
    from .utils import Utils
    from .messages import Messages, ErrorMessages
    
#=== CONSTANTS ================================================================
logger = logging.getLogger(__name__)

#=== CLASSES ==================================================================
class RequestExecutor():
    # The object which holds RequestParamHandler 
    def __init__(self, reqParamHandler):
        '''
            :type reqParamHandler: RequestParamHandler
            :param reqParamHandler: RequestParamHandler object                
        '''            
        self._reqParamHandler = reqParamHandler
        
    @property
    def reqParamHandler(self):
        return self._reqParamHandler
      
    def execute_request(self):
        '''
         1) Build HTTP request
         2) Execute HTTP request (Call the REST endpoint)
         3) Pass on the response to ResponseHandler
        '''
        # Build HTTP request
        session = requests.Session()
        request = self._build_request(self.reqParamHandler)
        utils = Utils()

        # Execute HTTP request (Call the REST endpoint)
        try:
            # commenting this. will need to revisit using the session for get.
            response = session.send(session.prepare_request(request))       
            req = response.request
            logger.debug("Response: Method: %s, url: %s, headers: %s." % (req.method, req.url, utils.get_response_header_with_no_auth(response.headers)))
            # Request succeeded, pass on the response to ResponseHandler
            ResponseHandler(response).process_response(self.reqParamHandler.output_format_cmd_level)
        except requests.exceptions.ConnectionError as ce:
            logger.error(ErrorMessages.OPAAS_CLI_CONNECTION_ERROR % ce)
            raise requests.exceptions.ConnectionError(ErrorMessages.OPAAS_CLI_CONNECTION_ERROR_DISPLAY % ce)
        except requests.exceptions.Timeout as te:
            logger.error(ErrorMessages.OPAAS_CLI_TIMEOUT_ERROR % te)
            raise requests.exceptions.Timeout(ErrorMessages.OPAAS_CLI_TIMEOUT_ERROR_DISPLAY % te)
        except requests.exceptions.InvalidURL as ie:
            logger.error(ErrorMessages.OPAAS_CLI_INVALID_URL_ERROR % ie)
            raise requests.exceptions.InvalidURL(ErrorMessages.OPAAS_CLI_INVALID_URL_ERROR_DISPLAY % request.url)
        except requests.exceptions.RequestException as e:
            logger.error(ErrorMessages.OPAAS_CLI_REQUESTS_ERROR % e)
            raise e
        finally:
            if session is not None:
                session.close()
                                                                                                                                                                                                                            
    def _build_request(self, reqParamHandler):
        '''
        Build HTTP request
        '''
        utils = Utils()
        defaultUri = utils.getValueFromConfigFile(utils.default_uri)
        method = reqParamHandler.method
        uri = reqParamHandler.uri
        content_type = reqParamHandler.contenttype
        headers = OrderedDict()
        bodyParams = dict()
        queryParams = dict()
        
        # Set identityDomainId
        identityDomain = utils.getValueFromConfigFile(utils.identity_domain)
        uri = uri.replace('{identityDomainId}', identityDomain)
 
        # headers
        headers['Authorization'] = utils.getAuthToken()
        headers[utils.identity_domain_header_key] = identityDomain        
        headers[utils.cli_request_key] = 'cli' # Value doesn't matter
        # Requests Module sets its own content type with boundary conditions for multipart/form-data .
        # for example: 'Content-Type': 'multipart/form-data; boundary=104ea81ca5814458b30984687aacb591'
        if content_type is not None and content_type != 'multipart/form-data':
            headers['Content-Type'] = content_type
        
        # path, query and body queryParams
        for param, value in reqParamHandler.cmd_params_values.items():
            paramType = reqParamHandler.param_dict[param]['paramType']
            type = reqParamHandler.param_dict[param]['type']
            if paramType == 'path':
                uri = uri.replace('{' + param + '}', value)
            elif paramType == 'query':
                queryParams[param] = value
            elif paramType == 'body':
                if type.lower() in ('json', 'file'):
                    # if content type is multipart then populate bodyparams as key, value.
                    # else populate bodyparam by updating the dict.
                    if content_type is not None and content_type.strip() == 'multipart/form-data':
                        bodyParams[param] = value
                    else:
                        if bool(bodyParams):
                            bodyParams.update(value)
                        else:
                            bodyParams = value                  
                elif type.lower() == 'list':
                    # FIX: Bug 22517700 - parse list into nested json.
                    nested_dict = {}
                    for key_value in value:
                        if ':' in key_value:
                            k,v = key_value.split(':')
                            nested_dict[k] = v
                        else:
                            nested_dict[key_value] = ""
                    bodyParams[param] = nested_dict
                else:
                    bodyParams[param] = utils.convertInputToJson(value)
            else:
                logger.debug('Unknown parameter type \'' + paramType + '\' for parameter \'' + param + '\'.')
                print('Unknown parameter type \'' + paramType + '\' for parameter \'' + param + '\'.')
        
        # data needs json object, hence json.dumps being used.
        # if the bodyParams/queryParams is empty then send None.
        files = None
        data = None
        # Fix: BUG 22504436: added files parameter for multipart/form-data content-type.
        if content_type is not None and content_type.strip() == 'multipart/form-data':  
            # FIX: BUG 22572441, 22572329: Fixed the form data by populating files using tuples. 
            files_tuple = []
            wrap_inside_list = []
            for k,v in bodyParams.items():
                wrapInsideValue = reqParamHandler.param_dict[k]['wrapInside'] if 'wrapInside' in reqParamHandler.param_dict[k] else None
                if (isinstance(v, dict)):
                    files_tuple.append((k, (k, str(json.dumps(v)))))
                elif wrapInsideValue:
                    wrap_inside_list.append(wrapInsideValue) 
                else:
                    files_tuple.append((k, ('', str(v))))            
            
            # create the payload with the wrapInside keywords value
            # BUG FIX: 22779287
            if len(wrap_inside_list) != 0:
                # removing duplicates
                wrap_inside_list = set(wrap_inside_list)
                for value in wrap_inside_list:
                    payload_dict = dict()
                    for k,v in bodyParams.items():
                        if 'wrapInside' in reqParamHandler.param_dict[k] and reqParamHandler.param_dict[k]['wrapInside'] ==  value:
                            payload_dict[k] = v
                    files_tuple.append((value, ('', str(json.dumps(payload_dict)))))
            
            # files has to be populated, so the content-type is set by the requests module. 
            # Hence, using empty string even if no params were specified.             
            if len(files_tuple) == 0:
                # Fix: BUG 22756412: to send an empty payload when content type is multipart/form-data 
                files = {'options': ('', str(dict()), content_type)}
            else:
                files = files_tuple
            # END.             
        else:
            data = json.dumps(bodyParams) if bool(bodyParams) else self._chkEmptyPayload(method)
        
        params = queryParams if bool(queryParams) else None
        request = requests.Request(method=method, url=defaultUri + uri, headers=headers, data=data, files=files, params=params)
        logger.debug("Request: Method: %s, url: %s, data: %s, files: %s, headers: %s." % (request.method, request.url, utils.changeValueOfPwd(request.data), request.files, utils.get_response_header_with_no_auth(request.headers)))

        return request
    
    # For GET requests in EDG and PROD env, need to send None.
    def _chkEmptyPayload(self, method):
        if method.lower() == 'get':
            return None
        else:
            return json.dumps(dict())
        