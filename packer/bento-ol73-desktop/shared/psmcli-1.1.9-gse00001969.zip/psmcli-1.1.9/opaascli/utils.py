# Copyright (c) 2015 Oracle and/or its affiliates. All rights reserved.
# created by sahit.gollapudi

import configparser as ConfigParser
import io
import json
import keyring
import os
import colorama
import platform
import re
import logging
from collections import OrderedDict
from pkg_resources import parse_version
try:
    from exceptions import OpaasConfigError
    from messages import LocalizationConstants, ErrorMessages
    from __init__ import __version__
except:
    from .exceptions import OpaasConfigError
    from .messages import LocalizationConstants, ErrorMessages
    from .__init__ import __version__
    

#=== CLASSES ==================================================================

class ReadConfigFile(ConfigParser.RawConfigParser):
    """
    based on ConfigParser from the standard library, modified to parse config
    files without sections.
    """

    def read(self, filename):
        text = open(filename).read()
        f = io.StringIO("[%s]\n" % NOSECTION + text)
        self.readfp(f, filename)

    def getoption(self, option):
        'get the value of an option'
        return self.get(NOSECTION, option)


    def getoptionslist(self):
        'get a list of available options'
        return self.options(NOSECTION)


    def hasoption(self, option):
        """
        return True if an option is available, False otherwise.
        (NOTE: do not confuse with the original has_option)
        """
        return self.has_option(NOSECTION, option)
    
    def write(self, fp):
        """
        overriding the default configparser to fit the need without section.
        Write the items from the default section manually and then remove them
        from the data. They'll be re-added later.
        """
        try:
            default_section_items = self.items(NOSECTION)
            self.remove_section(NOSECTION)

            for (key, value) in default_section_items:
                fp.write("{0} = {1}\n".format(key, value))

            # fp.write("\n")
        except ConfigParser.NoSectionError:
            pass

        ConfigParser.RawConfigParser.write(self, fp)
        self.add_section(NOSECTION)
        for (key, value) in default_section_items:
            self.set(NOSECTION, key, value)
    


class Utils(object):
    # a general class to get config values and general utility apis.
    
    DATA_TYPES = {
            str: 'string',
            float: 'float',
            int: 'integer',
            'bool': 'boolean',
            json.loads:'json',
            'FileType(\'r\')':'file',
            'list': '(list) (space separated)',
    }
    
    def __init__(self):
        self._readConfigFile = ReadConfigFile()
        usrHome = os.path.expanduser('~')

        # values for build no.
        self._build_version_key = 'X-PSM-CLI-ARTIFACT-VERSIONS'
        self._cli_request_key = 'X-PSM-CLI-REQUEST'
        self._version_split_token = '::'

        # identityDmain request header param name
        self._identity_domain_header_key = 'X-ID-TENANT-NAME'
                        
        # setup values
        self.opcDir = usrHome + "/.psm"
        self.subOpcDir = ['conf', 'data', 'log']
        self._cli_keyring_name = 'psm-cli'
        
        # Labels
        self._username_lbl = 'Username'
        self._pwd_lbl = 'Password'
        self._identity_domain_lbl = 'Identity domain'
        self._display_region_lbl = 'Region [us]'
        self._outputFormat_lbl = 'Output format [json]'
        
        # values stored in conf.
        self._username = 'username'
        self._passwd = 'password'
        self._identityDomain = 'identityDomain'
        self._default_uri = 'defaultURI'
        self._outputFormat = 'outputFormat'        
        self._log_level = 'logLevel'

        self._setupList = [self._identity_domain_lbl, self._display_region_lbl , self._outputFormat_lbl]
        self._confFile = "/conf/setup.conf"  
        self._dataFile = "/data/catalog.json" 
        self._logFile = "/psmcli.log" 
        
        # common values for output format for setup.
        self._default_output_value = 'json'
        self._get_output_format_values = ['json', 'html']
        self._default_log_level = INFO
        self._get_available_log_levels = [DEBUG.lower(), INFO.lower(), WARNING.lower(), ERROR.lower(), CRITICAL.lower()]
        
        # values for cliparser
        self._opc_data_dir = self.opcDir + "/data"
        self._service_index_filename = "/service-index.json"
        self._opc_log_dir = self.opcDir + "/log"
        self._output_format_override = 'outputFormat'
        
        # determine the platform
        self._system = platform.system()

        # values to store the downloaded client zip
        self._tmp_storage_linux = "/tmp/psmcli.zip"
        self._tmp_storage_win = "C:/temp/psmcli.zip"   # the / is being used here, as python will convert it.
        
        # arguments for the set-log-level
        self._log_level_parameter = ['--level', '-l'] 
        self._convert_camel_case = re.compile('((?<=[a-z0-9])[A-Z]|(?!^)[A-Z](?=[a-z]))')

    
    @property 
    def get_available_log_levels(self):
        return self._get_available_log_levels
    
    @property 
    def default_log_level(self):
        return self._default_log_level

    @property 
    def output_format_override(self):
        return self._output_format_override
    
    @property
    def tmp_storage_win(self):
        return self._tmp_storage_win
    
    @property 
    def tmp_storage_linux(self):
        return self._tmp_storage_linux
    
    @property 
    def service_index_filename(self):
        return self._service_index_filename
    
    @property 
    def opc_data_dir(self):
        return self._opc_data_dir 
    
    @property 
    def opc_log_dir(self):
        return self._opc_log_dir
    
    @property 
    def default_output_value(self):
        return self._default_output_value
    
    @property 
    def get_output_format_values(self):
        return self._get_output_format_values
    
    @property 
    def conf_file_name(self):
        # concatenate to give the full path as a string.
        return self.opcDir + self._confFile
    
    @property 
    def data_file_name(self):
        # concatenate to give the full path as a string.
        return self.opcDir + self._dataFile
    
    @property 
    def log_file_name(self):
        # concatenate to give the full path as a string.
        return self.opc_log_dir + self._logFile           
    
    @property
    def conf_file(self):
        return self._confFile
    
    @property 
    def data_file(self):
        return self._dataFile
    
    @property
    def log_file(self):
        return self._logFile
    
    @property
    def getsetuplist(self):
        return self._setupList
    
    @property 
    def log_level(self):
        return self._log_level
    
    @property
    def log_level_argument(self):
        return self._log_level_parameter
    
    @property
    def output_format(self):
        return self._outputFormat
    
    @property 
    def identity_domain(self):
        return self._identityDomain
    
    @property
    def cli_keyring_name(self):
        return self._cli_keyring_name
    
    @property
    def username_lbl(self):
        return self._username_lbl
    
    @property
    def username(self):
        return self._username
    
    @property 
    def password(self):
        return self._passwd
    
    @property 
    def default_uri(self):
        return self._default_uri
    
    @property 
    def region(self):
        return self._display_region_lbl
        
    @property 
    def cli_request_key(self):
        return self._cli_request_key
    
    @property 
    def identity_domain_header_key(self):
        return self._identity_domain_header_key
    
    @property
    def build_version_key(self):
        return self._build_version_key
    
    def readConfigFile(self):
        # import configreader
        cp = self._readConfigFile
        if os.path.exists(self.conf_file_name):
            cp.read(self.conf_file_name)
            return cp;
        else:
            return None
    
    def getValueFromConfigFile(self, value):
        # reads the value from the config value for specified key.
        cp = self.readConfigFile()
        if cp and value.lower() in cp.getoptionslist():
            return cp.getoption(value.lower())
        else:
            logger.debug(ErrorMessages.OPAAS_CLI_CONFIG_FILE_READ_ERROR % value)
            raise OpaasConfigError
        
    def getValueConfigFileOrReturnsNone(self, value):
        # reads the value from the config value for specified key.
        cp = self.readConfigFile()
        if cp and value.lower() in cp.getoptionslist():
            return cp.getoption(value.lower())
        else:
            return None
        
    def writeValueToConfigFile(self, key, value):
        # write the value to the config file. either adds a value
        # if not present or overrides the current value.
        cp = self._readConfigFile
        cp.set(NOSECTION, key, value)
        with open(self.conf_file_name, 'w') as configfile:
              cp.write(configfile)
 
    def writeTestValue(self, value):
        self.writeValueToConfigFile(self.log_level, value)
        
    def getAuthToken(self):
        # return the auth token that is stored in the keyring.
        user = self.getValueFromConfigFile(self.username)
        token = keyring.get_password(self.cli_keyring_name, user)
        return token
    
    def removeFilesFromDir(self, dir, filetype):
        # removes all the files in the directory based on the filetype.
        filelist = [ f for f in os.listdir(dir) if f.endswith(filetype) ]
        for f in filelist:
            os.remove(dir + "/" + f)
    
    def isWindows(self):
        return self._system.lower() == 'windows'
    
    def isLinux(self):
        return self._system.lower() == 'linux'
    
    def get_existing_cli_artifacts_versions(self):
         existing_cli_version, last_updated_time, ctlg_version = self.parse_cli_artifacts_versions(self.getValueFromConfigFile(self.build_version_key))
         # Always return the installed client version for the existing_cli_version
         return __version__, last_updated_time, ctlg_version    
     
    # this parses the build version key which has the 
    # client version::last_updated_time::catalog_build_version
    # returns client_version, last_updated_time, catalog_build_version
    def parse_cli_artifacts_versions(self, build_version):
        build_version_split = build_version.split(self._version_split_token)
        client_version = build_version_split[0]
        last_updated_time = build_version_split[1]
        # Send None, if the catalog_build_version doesnt exists for prior versions before 1.1.9
        catalog_build_version = build_version_split[2] if len(build_version_split) == 3 else None
        return client_version, last_updated_time, catalog_build_version
    
    # concats the client version, and last update time
    # with the default split_token.
    # NOTE: order of the concat needs to be maintained.
    def concat_cli_artifacts_versions(self, client_version, last_updated_time, catalog_build_version):
        if catalog_build_version is not None:
            return self._version_split_token.join([client_version, last_updated_time, catalog_build_version.strip()])
        else:
            # This is for backward compatiblity of the CLI with a previous version of SM.
            return self._version_split_token.join([client_version, last_updated_time])
     
    
    def checkVersionEquality(self, existing_version, new_version):
        return parse_version(existing_version) == parse_version(new_version) 
    
    # The order matters. check if version one is greater than two.
    def checkVersionGreaterThan(self, version_one, version_two):
        return parse_version(version_one) > parse_version(version_two)
    
    # to get the value of the client_version
    def get_existing_cli_version(self):
        return __version__
    
    # Get existing cli version from conf file
    def get_existing_file_cli_verion(self):
        existing_artifacts_versions = self.getValueConfigFileOrReturnsNone(self.build_version_key)
        if existing_artifacts_versions is None:
            return None
        else:
            client_version = existing_artifacts_versions.split(self._version_split_token) 
            return client_version[0]
        
    # updates only catalog and last updated time if setup is run again.
    def checkCatalogTokensAndUpdate(self, existing_client_version, cli_artifacts_versions):
        if existing_client_version is None:
            self.writeValueToConfigFile(self.build_version_key, cli_artifacts_versions)
        else:
            new_client_version, new_last_updated_time, catalog_build_version = self.parse_cli_artifacts_versions(cli_artifacts_versions)
            self.writeValueToConfigFile(self.build_version_key, \
                                        self.concat_cli_artifacts_versions(existing_client_version, \
                                                                            new_last_updated_time, \
                                                                            catalog_build_version))

    # return response headers removing the authorization token.
    def get_response_header_with_no_auth(self, headers):
        
        if headers is not None:
            dict_header = OrderedDict(headers)
            if 'Authorization' in dict_header:
                del dict_header['Authorization']
                return dict_header
        # if nothing to delete return the default.
        return headers
    
    # replace the public url with the region.
    def get_public_domain_url(self, region_name):
        # if the region name doesnt exists in the mapping dict, 
        # return the value entered.
        if region_name in LocalizationConstants.RegionMapping:
            public_url = LocalizationConstants.Default_URI.replace('region', LocalizationConstants.RegionMapping[region_name])
            return public_url
        else:
            return region_name    
    
    # convert the camelcase to lowercase seperated by '-'
    def convertCamelCase(self, value):
         return self._convert_camel_case.sub(r'-\1', value).lower()
     
    # change the value of the password if exists for logging purpose.
    def changeValueOfPwd(self, data):
        if bool(data):
            data_dict = data
            try:                        
                data_dict = self.changeValueOfPwdRecurrsive(json.loads(data))                      
            except:
                pass
            return data_dict
        else:
            return data
    
    def changeValueOfPwdRecurrsive(self, data_dict):        
        for key, value in data_dict.items():
            if isinstance(value, dict):
                self.changeValueOfPwdRecurrsive(value)
            elif isinstance(value, list):
                for list_item in value:
                    self.changeValueOfPwdRecurrsive(list_item)
            elif any(value in key.lower() for value in ['pwd', 'password', 'passwd', 'cred']):
                data_dict[key] = "*******"
        
        return data_dict          

    # this is to parse the value from the catalog for boolean values 
    # which will return json standard output.
    def parseValueForBoolean(self, value):        
        if value.lower() == 'false':
            return False
        elif value.lower() == 'true':
            return True

        return value  
    
    # to check if given var is empty or not
    def isNotBlank(self, value):
        if value and value.strip():
            # value is not empty
            return True
        
        return False
    
    # convert string to json.
    def convertInputToJson(self, value): 
        return_value = value
        try:
            data_dict = json.loads(value)
            if isinstance(data_dict, dict):
                return_value = data_dict
        except:
            pass
        
        return return_value    
        
  
class TerminalStyler(object): 
    # A terminal color mechanism which has different options of colorizing the 
    # text in the terminal. Using colorama to enable this. At present we need
    # only bold.
    
    def __init__(self):
        colorama.init(autoreset=True)
    
    def format_bold(self, msg):
        return (colorama.Style.BRIGHT + msg + colorama.Style.RESET_ALL)

    def format_green(self, msg):
        return (colorama.Fore.GREEN + msg + colorama.Style.RESET_ALL)
    
    def format_blue(self, msg):
        return (colorama.Fore.BLUE + msg + colorama.Style.RESET_ALL)

    def format_black(self, msg):
        return (colorama.Fore.BLACK + msg + colorama.Style.RESET_ALL)
    
    def format_red(self, msg):
        return (colorama.Fore.RED + msg + colorama.Style.RESET_ALL)    
    
        
class FormatText(object):
    
    #====== FORMAT =======#
    HEADER = '\033[95m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[04m'
    
    #====== COLORS =======# 
    BLACK = '\033[30m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    ORANGE = '\033[33m'
    BLUE = '\033[34m'
    PURPLE = '\033[35m'
    CYAN = '\033[36m'
    LIGHTGREY = '\033[37m'
    DARKGREY = '\033[90m'
    LIGHTRED = '\033[91m'
    LIGHTGREEN = '\033[92m'
    YELLOW = '\033[93m'
    LIGHTBLUE = '\033[94m'
    PINK = '\033[95m'
    LIGHTCYAN = '\033[96m'
    
    STYLER = TerminalStyler()
    
    def disable():
        HEADER = ''
        WARNING = ''
        FAIL = ''
        ENDC = ''
    
    @classmethod 
    def formatgreen(cls, msg):
        # return (cls.GREEN + msg + cls.ENDC)
        return cls.STYLER.format_green(msg)
       
    @classmethod
    def formatblue(cls, msg):
        return cls.STYLER.format_blue(msg)

    @classmethod
    def formatblack(cls, msg):
        return cls.STYLER.format_black(msg)
    
    @classmethod
    def formatred(cls, msg):
        return cls.STYLER.format_red(msg)    
    
    @classmethod
    def bold(cls, msg):
        return cls.STYLER.format_bold(msg)
    

#=== MODULE METHODS ================================================================

def get_log_filename():
    utils = Utils()
    if not os.path.exists(utils.opcDir):
        os.makedirs(utils.opcDir)
    if not os.path.exists(utils.opc_log_dir):
        os.makedirs(utils.opc_log_dir)
    
    return utils.log_file_name

def get_log_level():
    utils = Utils()
    cp = utils.readConfigFile()
    if cp and utils.log_level.lower() in cp.getoptionslist():
        # return the log leve in upper case for configuration.
        return cp.getoption(utils.log_level.lower()).upper()
    else:
        return INFO
    

#=== CONSTANTS ================================================================

logger = logging.getLogger(__name__)

#LOG LEVEL CONSTANTS
INFO = 'INFO'
DEBUG = 'DEBUG'
ERROR = 'ERROR'
CRITICAL = 'CRITICAL'
WARNING = 'WARNING'

# section name for options without section:
NOSECTION = 'NOSECTION'

LOGGING_CONFIG = {
    'version': 1,              
    'disable_existing_loggers': False,

    'formatters': {
        'standard': {
            'format': '%(asctime)s [%(levelname)s] %(module)s: %(message)s',
            'datefmt': '%b %d %H:%M:%S'
        },
    },
    'handlers': {
        'default': {
            'class': 'logging.handlers.RotatingFileHandler',
            'formatter': 'standard',
            'filename': get_log_filename(),
            'maxBytes': 10485760,
            'backupCount': 10,
            'encoding': 'utf8'
        },  
    },
    'loggers': {
        '': {                  
            'handlers': ['default'],        
            'level': get_log_level(),  
            'propagate': True  
        }
    }
}
