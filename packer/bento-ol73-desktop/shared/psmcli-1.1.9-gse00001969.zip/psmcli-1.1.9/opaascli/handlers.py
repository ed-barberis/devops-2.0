# Copyright (c) 2015 Oracle and/or its affiliates. All rights reserved.
# created by sahit.gollapudi, abhijit.jere
import requests
import sys
import io
import re
import os
import yaml
import json
import logging
from collections import OrderedDict
from pkg_resources import parse_version
try:
    from exceptions import ResponseNullError, DataNotFoundError
    from formatter import OUTPUT_FORMATTER
    from utils import Utils, FormatText
    from opcservice import OPCService
    from messages import Messages, ErrorMessages
except:
    from .exceptions import ResponseNullError, DataNotFoundError
    from .formatter import OUTPUT_FORMATTER
    from .utils import Utils, FormatText
    from .opcservice import OPCService
    from .messages import Messages, ErrorMessages

#=== CLASSES ================================================================


class RequestParamHandler(object):
    # The object which holds the service name, cmd name 
    # and the parameter values for that cmd. 
    
    def __init__(self, srv_name, cmd_name,
                options_args_parsed,
                arg_parameter_list,
                method, uri, contentType,
                param_dict):
        """
            :type srv_name: str
            :param srv_name: service name.
            
            :type cmd_name: str
            :param cmd_name: command name.
            
            :type options_args_parsed: namespace object
            :param options_args_parsed: holds the namespace object with the cmd line values.
            
            :type arg_parameter_list: dict
            :param arg_parameter_list: holds the instance of OPCArgument for all available parameters.
            
            :type method: str
            :param method: rest api method type.
            
            :type uri: str
            :param uri: url for the rest api.
            
            :type contenType: str
            :param contentType: contentType for post, put, delete operations..     
            
            :type param_dict: dict
            :param param_dict: values for that command parameters.
        """
        self.utils = Utils()
        self._srv_name = srv_name
        self._cmd_name = cmd_name
        self._options_args_parsed = options_args_parsed
        self._arg_parameter_list = arg_parameter_list
        self._method = method
        self._uri = uri 
        self._content_type = contentType
        self._param_dict = param_dict
        self._cmd_params_values = {}
        # value modified if outputformat is specified at command level
        self._output_format_cmd_level = None
        # build the values from the args.
        self._build_option_value()
    
    @property
    def output_format_cmd_level(self):
        return self._output_format_cmd_level
    
    @output_format_cmd_level.setter 
    def output_format_cmd_level(self, value):
        self._output_format_cmd_level = value
    
    @property
    def srv_name(self):
        return self._srv_name
    
    @property
    def cmd_name(self):
        return self._cmd_name
    
    @property
    def options_args_parsed(self):
        return self._options_args_parsed
    
    @property
    def param_dict(self):
        return self._param_dict
    
    @property
    def method(self):
        return self._method
    
    @property
    def uri(self):
        return self._uri
    
    @property
    def contenttype(self):
        return self._content_type
    
    @property
    def cmd_params_values(self):
        return self._cmd_params_values
    
    @cmd_params_values.setter
    def cmd_params_values(self, value):
        self._cmd_params_values = value
    
    @property 
    def arg_parameter_list(self):
        return self._arg_parameter_list
    
    @arg_parameter_list.setter 
    def arg_parameter_list(self, value):
        self._arg_parameter_list = value
        
    def _build_option_value(self):
        # this is to extract the values passed ib the command line
        # for the options specified for each command.
        # convert options_args_parsed using vars as its a namespace object
        args_parsed = vars(self.options_args_parsed)
        
        # check for output format at cmd level. if exists then set the value
        # for the executor to pass it on to the response handler.
        if self.utils.output_format_override in args_parsed and args_parsed[self.utils.output_format_override] is not None:            
            self.output_format_cmd_level = args_parsed[self.utils.output_format_override]
            logger.debug('the output format is overriden: %s', self.output_format_cmd_level)
            
        # arg parameter list has the instance of OPCArgument.
        arg_parameter_list = self.arg_parameter_list
        for arg_instance in arg_parameter_list.values():
            name = arg_instance.dest_name
            if name in args_parsed:
                value = args_parsed[name]
                # reading the value of the args if its of instance file
                if isinstance(value, io.TextIOWrapper):
                    streamValue = value.read()
                    # initializing the value to None.
                    value = None
                    try:
                        # read for json file input first.
                        value = json.loads(streamValue)                   
                    except ValueError as e:
                        logger.error("Error while parsing the input as json: %s", e)
                        logger.info("Trying to parse the file as Yaml.")
                    
                    # check if value empty, send content as is if its yaml.
                    if value is None or not isinstance(value, dict):
                        try:
                            yaml.load(streamValue)
                            value = streamValue
                        except yaml.YAMLError as exc:
                            logger.error("Error while parsing the input as yaml: %s", exc)
                    
                    if value is None:
                        lines = streamValue.split('\n')
                        clean_lines = [l.strip() for l in lines if l.strip()]
                        value = ''.join(clean_lines)
                
                # add each param name and value in to 
                # dict for executor to build the request.
                if value is not None:
                    self.cmd_params_values[name] = value
        
        # this is to add the hidden constant values to send it 
        # accross the rest endpoints.
        if bool(self.param_dict):
            for key, value in self.param_dict.items():
                if 'hiddenConstant' in value:
                    self.cmd_params_values[key] = value['hiddenConstant']
                # FIX: BUG 22736148. Sending a default value in the payload if 
                # the rest api requires an empty payload to be sent.
                if 'defaultValue' in value and key not in self.cmd_params_values:
                    self.cmd_params_values[key] = self.utils.parseValueForBoolean(value['defaultValue'])
                    
        # add the command executed to the log.
        logger.debug("command executed: %s", ' '.join([Messages.OPAAS_CLI_TOP_LEVEL_SCRIPT_NAME.strip(), self.srv_name, self.cmd_name, ' '.join(self.cmd_params_values.keys())]))


#====== Response Handlers ========
class ResponseHandlerFactory(object):
    """
        A factory that returns the desired response handler
        based on the content_type
    """
    
    def __init__(self):
        pass

    def create_handler(self, applicationType):
        # We observed many custom media types for json, e.g. application/vnd.com.oracle.oracloud.provisioning.Pod+json
        # and application/vnd.com.oracle.oracloud.provisioning.Service+json. Using standard 'application/json' handler
        # for such instances.
        if Messages.OPAAS_CLI_JSON_KEY in applicationType:
            applicationType = 'application/json'
        elif Messages.OPAAS_CLI_TEXT_KEY in applicationType:
            applicationType = 'text/plain'
        else:
            # defaulting mediatype to 'text/plain' if an unknown media type is encountered.
            applicationType = 'text/plain'
        logger.debug("The Content-type: %s", applicationType)
        resolver = RESPONSE_HANDLERS[applicationType]
        return resolver()
   

# pub api to build the factory response resolver.
def create_response_handler(applicationType):
    return ResponseHandlerFactory().create_handler(applicationType)           


class BaseResponseHandler(object):
    """
        This class has the ability to parse the response based on the content
        type and will return the processed response with an error msg if any
        or returns the content from the response.
    """
    def __init__(self):
        self._utils = Utils()
    
    def _handle_response_error(self, respone):
        """
           to be implemented by the subclasses. By default it will raise 
           an Exception.
        """
        raise NotImplementedError("Not Implemented")

    def _handle_response_output(self, response):
        """
           to be implemented by the subclasses. By default it will raise 
           an Exception.
        """
        raise NotImplementedError("Not Implemented")
    
    def _format_response(self, data):
        """
           to be implemented by the subclasses. By default it will raise 
           an Exception.
        """
        raise NotImplementedError("Not Implemented")
            
class JSONResponseHandler(BaseResponseHandler):
    
    def _handle_response_output(self, response):
        # TODO: to work on the formatting of json if any unknown issues arise.
        try:
            output = response.json(object_pairs_hook=OrderedDict)  # {'output':'output'}
        except:
            if self._utils.isNotBlank(response.content):
                output = response.content
                if isinstance(output, bytes):
                    output = output.decode('ascii')
            else:
                output = response.reason if self._utils.isNotBlank(response.reason) else response.text 
        return output  
    
    def _handle_response_error(self, response):
        # TODO: to parse the error more generically for all error types
        error_content = None
        try:
            error_content = response.json()
        except:
            error_content = response.content.decode('ascii')
            
        if error_content:
            return self._format_response(error_content)
        return error_content   
    
    def _format_response(self, data):
        formatter = OUTPUT_FORMATTER[Messages.OPAAS_CLI_JSON_KEY](data)
        parsed_content = formatter._format_content()
        return ("\n%s" % parsed_content)

class TextResponseHandler(BaseResponseHandler):
    
    def _handle_response_output(self, response):
        # TODO: to work on the remaining parsing options if any
        try:
            content = response.content
            if isinstance(content, bytes):
                content = content.decode('ascii')
        except:
            content = response.reason if self._utils.isNotBlank(response.reason) else response.text 
        return content
    
    def _handle_response_error(self, response):
        reason = []
        response_reason = None
        if self._utils.isNotBlank(response.reason):
            response_reason = response.reason 
            reason.append(response.reason)
        if self._utils.isNotBlank(response.text):
            if response_reason is not None and response_reason.strip() == response.text.strip():
                pass                    
            else:
                reason.append(response.text)
        reason = '. '.join(reason)  
        if reason:
            return self._format_response(reason)
        return reason 
    
    def _format_response(self, data):
        formatter = OUTPUT_FORMATTER[Messages.OPAAS_CLI_TEXT_KEY](data)
        parsed_reason = formatter._format_content()
        return ("%s" % parsed_reason)        

class XMLResponseHandler(BaseResponseHandler):
    pass

   
class ResponseHandler():
    # The object which holds HTTP response from REST endpoint 
    def __init__(self, response):
        """
            :type response: requests.Response
            :param response: HTTP response from REST endpoint                
        """            
        self._response = response
        self._utils = Utils()
        self._existing_client_version, self._existing_last_updated_time, self._existing_catalog_build_version = self._utils.get_existing_cli_artifacts_versions()
        self._existing_file_client_version = self._utils.get_existing_file_cli_verion()
        self._job_status_msg = Messages.OPAAS_CLI_JOB_STATUS_ID_MSG
        
    @property
    def response(self):
        return self._response

    def process_response(self, output_format=None):
        '''
        Process HTTP response and display output to the user in desired format
        '''        
        if self.response is None:
            raise ResponseNullError()    
        else: 
            response = self.response
            # BUG FIX: 22565495 Fix to read default content type. 
            applicationType = response.headers['Content-Type'] if 'Content-Type' in response.headers else 'text/plain'
            status_code = response.status_code
            
            response_handler = create_response_handler(applicationType)
            
            # check for codes less than 300. requests.codes has a list of error codes
            # that can be used to determine the nature of error. #TODO.
            if status_code >= 300:
                if status_code == 404:
                    logger.error(ErrorMessages.OPAAS_CLI_NO_DATA_FOUND)
                    sys.stdout.write('%s\n'%ErrorMessages.OPAAS_CLI_NO_DATA_FOUND)
                else:  
                    parsed_error = response_handler._handle_response_error(response)
                    logger.error(ErrorMessages.OPAAS_CLI_LOGGER_ERROR_MSG, parsed_error)
                    sys.stdout.write(ErrorMessages.OPAAS_CLI_STD_ERR_MSG % parsed_error)
                
                # checking the cli artifact versions to update the catalog.
                self.checkBuildNumAndUpdate(response)
                
                # BUG FIX: 22538243. Return error exit code. 
                sys.exit(1)
            else:
                output = response_handler._handle_response_output(response)        
                outFormatter = self._utils.getValueFromConfigFile(self._utils.output_format)

                # to route to the proper formatter based on content type.
                if 'json' not in applicationType:
                    outFormatter = 'text'
                                     
                formatter = OUTPUT_FORMATTER[outFormatter](output) if output_format is None else OUTPUT_FORMATTER[output_format](output)             
                # display the output.
                sys.stdout.write('%s\n' % formatter._format_content())
                # display job id if exists for monitoring using view-operation-status.
                self.display_job_id_for_monitoring_status(response.headers)
                
            # checking the cli artifact versions to update the catalog.
            self.checkBuildNumAndUpdate(response)
            
    
    # api to display the job id if it exists.
    def display_job_id_for_monitoring_status(self, headers): 
        response_location = headers['Location'] if 'Location' in headers else None
        if response_location is not None:
            try:
                # match the location header with the regex Job id as of now is numeric eval.
                match = re.match(r"(?P<joburl>.*/(job|opStatus)/)(?P<jobid>.[0-9]+)", response_location)
                if match is None:
                    return
                job_id = match.group('jobid')
                # display jobId only if it exists
                if job_id:
                    sys.stdout.write(self._job_status_msg%job_id)    
            except Exception as e:
                logger.error(ErrorMessages.OPAAS_CLI_FAIL_JOB_ID, e)
                    
    def checkBuildNumAndUpdate(self, response):
        cli_artifacts_versions = response.headers[self._utils.build_version_key] if self._utils.build_version_key in response.headers else None
        if cli_artifacts_versions is None:
            return
        service = OPCService()
        new_client_version, new_last_updated_time, new_catalog_build_version = self._utils.parse_cli_artifacts_versions(cli_artifacts_versions)
        # update only if the new catalog version is greater than the existing one.
        if self._existing_last_updated_time is None or \
                       self._utils.checkVersionGreaterThan(new_last_updated_time.strip(), self._existing_last_updated_time.strip()):
            
            # False is when the catalog is updated implicit.
            if service.callRestApiGetServiceTypes(False):
                self._utils.writeValueToConfigFile(self._utils.build_version_key, \
                        self._utils.concat_cli_artifacts_versions(self._existing_client_version.strip(), \
                                                                        new_last_updated_time.strip(), \
                                                                        new_catalog_build_version))            
        elif self._existing_catalog_build_version is None or \
                not self._utils.checkVersionEquality(self._existing_client_version, self._existing_file_client_version):
            # Maintain catalog_build_version and client_version for debugging purpose.
            self._utils.writeValueToConfigFile(self._utils.build_version_key, \
                self._utils.concat_cli_artifacts_versions(self._existing_client_version.strip(), \
                                                            self._existing_last_updated_time.strip(), \
                                                            new_catalog_build_version)) 
                             
        # display a message only if the new client version is greater than the existing one.
        if self._existing_client_version is not None and \
                       self._utils.checkVersionGreaterThan(new_client_version.strip(), self._existing_client_version.strip()):
            sys.stdout.write('%s: %s\n' % (FormatText.bold(Messages.OPAAS_CLI_WARNING_MSG), Messages.OPAAS_CLI_UPGRADE_WARNING_MSG))


#=== CONSTANTS ================================================================

RESPONSE_HANDLERS = {
    'application/json': JSONResponseHandler,
    'text/plain': TextResponseHandler,
    'application/xml' : XMLResponseHandler,
}

logger = logging.getLogger(__name__)
