# Copyright (c) 2015 Oracle and/or its affiliates. All rights reserved.
# created by sahit.gollapudi


"""scripts.opcservice: opcservice module within the opc package"""


import requests
import sys
import json
import zipfile
import io
import os
import keyring
import logging 
from collections import OrderedDict
try:
    from utils import Utils
    from messages import Messages, ErrorMessages
except:
    from .utils import Utils
    from .messages import Messages, ErrorMessages

# Logger
logger = logging.getLogger(__name__)

class OPCService(object):
    # Set the request parameters

    def __init__(self):
        self._cnf = Utils()
        self._fileSeparator = "/"
    
    def checkCredentials (self, token, identityDomain, urlHostName, return_cli_artifacts_upgrade=False):  
        """
            :type return_cli_artifacts_upgrade: bool
            :param return_cli_artifacts_upgrade: is true when it is called for upgrade cli to retrieve the header info.
        """
        # to check if the credentials are valid.
        urlHost = urlHostName
        urlChkConnection = '/paas/api/v1.1/cli/' + identityDomain + '/client?type=connection' 
        
        url = urlHost + urlChkConnection

        try:
            logger.info(Messages.OPAAS_CLI_CHK_CONN)
            logger.debug("Request: url: %s, headers: %s" % (url, {self._cnf.cli_request_key : 'cli', self._cnf.identity_domain_header_key : identityDomain}))
            
            response = requests.get(url, headers={'Authorization' : token, self._cnf.cli_request_key : 'cli', self._cnf.identity_domain_header_key : identityDomain})

            # Check for HTTP codes for 200
            logger.debug("Response: Method: %s, url: %s, headers: %s" % (response.request.method, response.request.url, self._cnf.get_response_header_with_no_auth(response.headers)))      
            
            if response.status_code == 200: 
                if return_cli_artifacts_upgrade:
                    return response.headers[self._cnf.build_version_key] if self._cnf.build_version_key in response.headers else None
                else:
                    return True
            else:
                logger.error(ErrorMessages.OPAAS_CLI_CHK_CONN_FAIL_ERROR % response.status_code)
                return response.status_code 
                        
        except (requests.exceptions.ConnectionError, requests.exceptions.InvalidURL, requests.exceptions.HTTPError) as e:
            logger.error(ErrorMessages.OPAAS_CLI_CONNECTION_ERROR % e)
            # invalid URI with connection refused.
            return 111
        except requests.exceptions.RequestException as e:
            logger.error(ErrorMessages.OPAAS_CLI_REQUESTS_ERROR % e)
            errMsg = "{}".format(e)
            if 'Invalid URL' in errMsg:
                return 111
            return False           
    
    def callRestApiGetServiceTypes(self, explicit, existing_client_version=None):
        """
            :type explicit: boolean
            :param explicit: true if the setup is run explicitly.
            
            :type existing_client_version: str
            :param existing_client_version: if setup is run multiple times, to retain the existing client version
        """
        # Do the HTTP get request
        try:
            
            token = self._cnf.getAuthToken()
            if not token:
               return False
            
            opcDir = self._cnf.opc_data_dir
            serviceIndexFile = self._cnf.opc_data_dir + self._cnf.service_index_filename
            
            urlHost = self._cnf.getValueFromConfigFile(self._cnf.default_uri)
            identityDomain = self._cnf.getValueFromConfigFile(self._cnf.identity_domain)
            urlGetServiceCatalog = '/paas/api/v1.1/cli/' + identityDomain + '/client?type=catalog' 

            logger.info(Messages.OPAAS_CLI_DOWNLOAD_CATALOG)
            logger.debug("Request: url: %s, headers: %s" % (urlHost + urlGetServiceCatalog, {self._cnf.cli_request_key : 'cli', self._cnf.identity_domain_header_key : identityDomain}))
            
            response = requests.get(urlHost + urlGetServiceCatalog, headers={'Authorization' : token, self._cnf.cli_request_key : 'cli', self._cnf.identity_domain_header_key : identityDomain})

            # Check for HTTP codes other than 200
            logger.debug("Response: Method: %s, url: %s, headers: %s" % (response.request.method, response.request.url, self._cnf.get_response_header_with_no_auth(response.headers)))      
            
            if response.status_code != 200:
               logger.error(ErrorMessages.OPAAS_CLI_STATUS_CODE_ERROR_DISPLAY % response.status_code)
               sys.stdout.write(ErrorMessages.OPAAS_CLI_STATUS_CODE_ERROR_DISPLAY % response.status_code)
               return False               
            
            logger.info(Messages.OPAAS_CLI_DOWNLOAD_CATALOG_SUCCESS)
            # read the content as a zip file.
            zipDocument = zipfile.ZipFile(io.BytesIO(response.content))
            ret = zipDocument.testzip()
            
            if ret is not None:
                logger.error(ErrorMessages.OPAAS_CLI_BAD_RESPONSE_ZIPFILE)
                sys.stderr.write(ErrorMessages.OPAAS_CLI_BAD_RESPONSE_ZIPFILE_DISPLAY)
                return False
            else:     
                if not os.path.exists(opcDir):
                    os.makedirs(opcDir)
                
                # remove the files in the directory bfr extracting
                self._cnf.removeFilesFromDir(opcDir, ".json")
                # extract to the directory
                zipDocument.extractall(path=opcDir)

            if explicit:
                # check for build no. if exist then update the build no no matter what. no check is required
                # to see if the build no is changed from previous.
                cli_artifacts_versions = response.headers[self._cnf.build_version_key] if self._cnf.build_version_key in response.headers else None
                if cli_artifacts_versions is not None:
                    self._cnf.checkCatalogTokensAndUpdate(existing_client_version, cli_artifacts_versions)
                # check if the file exist. to ensure that the extraction was successful.
                with open(serviceIndexFile) as json_file:
                     data = json.load(json_file, object_pairs_hook=OrderedDict)
                sys.stdout.write('----------------------------------------------------\n')
                sys.stdout.write(str(Messages.OPAAS_CLI_SETUP_SUCCESS_MSG))
                services = data['services']
                for service, value in services.items():
                    sys.stdout.write("  o %s : %s\n" % (service, value))
                sys.stdout.write('----------------------------------------------------\n')
            
            return True
        except requests.exceptions.RequestException as e:
            logger.error(ErrorMessages.OPAAS_CLI_REQUESTS_ERROR % e)
            sys.stderr.write ("Error : {}\n".format(e))

    # api used to download the client for psm upgrade.
    def callRestApiToDownloadClient(self):
        # Do the HTTP get request
        try:
            
            token = self._cnf.getAuthToken()
            if not token:
               return
           
            tmp_storage = self._cnf.tmp_storage_win if self._cnf.isWindows() else self._cnf.tmp_storage_linux
            serviceIndexFile = self._cnf.opc_data_dir + self._cnf.service_index_filename

            urlHost = self._cnf.getValueFromConfigFile(self._cnf.default_uri)
            identityDomain = self._cnf.getValueFromConfigFile(self._cnf.identity_domain)
            urlGetClientZip = '/paas/api/v1.1/cli/' + identityDomain + '/client' 
            
            logger.info(Messages.OPAAS_CLI_DOWNLOAD_KIT)
            logger.debug("Request: url: %s, headers: %s" % (urlHost + urlGetClientZip, {self._cnf.cli_request_key : 'cli', self._cnf.identity_domain_header_key : identityDomain}))
            
            # call to download the cli.
            response = requests.get(urlHost + urlGetClientZip, headers={'Authorization' : token, self._cnf.cli_request_key : 'cli', self._cnf.identity_domain_header_key : identityDomain})
            
            logger.debug("Response: Method: %s, url: %s, headers: %s" % (response.request.method, response.request.url, self._cnf.get_response_header_with_no_auth(response.headers)))      

            # Check for HTTP codes other than 200
            if response.status_code != 200:
               logger.error(ErrorMessages.OPAAS_CLI_DOWNLOAD_KIT_ERROR % response.status_code)
               sys.stdout.write(ErrorMessages.OPAAS_CLI_STATUS_CODE_ERROR_DISPLAY % response.status_code)
               # Error will result in no zip file and hence exit.
               sys.exit(0)
               # comment the above one for testing once the kit has downloaded and uncomment the below line.
               # return tmp_storage            
            
            # read the content as a zip file.
            zipDocument = zipfile.ZipFile(io.BytesIO(response.content))
            ret = zipDocument.testzip()
            
            if ret is not None:
                logger.error(ErrorMessages.OPAAS_CLI_DOWNLOAD_KIT_CORRUPTED_DISPLAY)
                sys.stdout.write(ErrorMessages.OPAAS_CLI_DOWNLOAD_KIT_CORRUPTED_DISPLAY)
                sys.exit(0)
            
            logger.info(Messages.OPAAS_CLI_DOWNLOAD_KIT_SUCCESS)
            # storing the zip into a location. TODO: add platform here.
            with open(tmp_storage, "wb") as code:
                code.write(response.content)               
            
            # return the filename with the location.
            return tmp_storage
        except requests.exceptions.RequestException as e:
            logger.error(ErrorMessages.OPAAS_CLI_REQUESTS_ERROR % e)
            sys.stderr.write ("Error : {}\n".format(e)) 
            sys.exit(0)
                  

