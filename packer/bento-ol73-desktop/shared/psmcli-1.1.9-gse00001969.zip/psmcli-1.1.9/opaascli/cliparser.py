# Copyright (c) 2015 Oracle and/or its affiliates. All rights reserved.
# created by sahit.gollapudi

import argparse
import sys
import os
import json
import textwrap
import logging
from collections import OrderedDict
try:
    from argumenttypes import OPCArgument
    from __init__ import __version__
    from helpformatter import OPCHelpCommand, OPCCustomHelpFormatter
    from configure import SetupParser
    from handlers import RequestParamHandler
    from executor import RequestExecutor
    from exceptions import UnknownArgumentError
    from utils import Utils
    from messages import Messages, ErrorMessages
except:
    from .argumenttypes import OPCArgument
    from .__init__ import __version__
    from .helpformatter import OPCHelpCommand, OPCCustomHelpFormatter
    from .configure import SetupParser
    from .handlers import RequestParamHandler
    from .executor import RequestExecutor
    from .exceptions import UnknownArgumentError
    from .utils import Utils 
    from .messages import Messages, ErrorMessages

# Logger
logger = logging.getLogger(__name__)

# a top level api to change the title for all the parsers
def change_title_of_arguments(parser, req_title, opt_title):
    for grp in parser._action_groups:
        if grp.title == 'positional arguments':
            grp.title = req_title
        elif grp.title == 'optional arguments':
            grp.title = opt_title

# a custom boolean type for the parser to parse the boolean values.
def custom_bool_type(v):
  return v.lower() in ("yes", "true", "t", "1")

# a Case Insensitive list type to check for values in a case 
# sensitive format: Bug fix: 23333311
class CaseInsensitiveList(list):
    # override the __contains__ method for custom rendering.
    def __contains__(self, input):
        for item in self:
            if item.lower() == input.lower():
                return True
        return False

# A custom Action for CLI version. # Bug Fix: 23525276. 
# Honoring the -v/--version argument.
class CLIVersionAction(argparse.Action):

    def __init__(self,
                 option_strings,
                 version=None,
                 dest=argparse.SUPPRESS,
                 default=argparse.SUPPRESS,
                 help="show program's version number and exit"):
        super(CLIVersionAction, self).__init__(
            option_strings=option_strings,
            dest=dest,
            default=default,
            nargs=0,
            help=help)
        self.version = version

    def __call__(self, parser, namespace, values, option_string=None):
        if namespace.service:
            return
        version = self.version
        if version is None:
            version = parser.version
        formatter = parser._get_formatter()
        formatter.add_text(version)
        parser._print_message(formatter.format_help(), sys.stdout)
        parser.exit()
            
# the psm parser which is the base parser for all the service, command, 
# parameter|options (argument) parsers.    
class OPCParser(argparse.ArgumentParser):
    """ PSM Client parser """
    
    Formatter = OPCHelpCommand  # argparse.RawDescriptionHelpFormatter
    Usage = Messages.OPAAS_CLI_USAGE
    helplist = ['h']
    versionList = ['-v', '--version']
    
    @property 
    def version_parser(self):
        # needs to be implemented by the sub classes. Default is False.
        # this is used to parse the special case of -v and --version handling.
        return False
    
    @property
    def command_list(self):
        # needs to be implemented by the sub classes otherwise it will return None.
        # this is returns a list of services/commands and their descriptions for help.
        return None    
    
    @property 
    def get_examples(self):
        # needs to be implemented by the sub classes. This returns examples associated with 
        # each command or service if there is one. If no examples, returns None.
        return None
    
    @property 
    def get_payload(self):
        # needs to be implemented by the sub classes. this will return a sample payload 
        # that will be displayed with the examples.
        return None
    
    def parse_known_args(self, args, namespace=None):
        helpvalue = list(set(self.helplist) & set(args)) 
        if helpvalue and len(helpvalue) == 1 and len(args) >= 1:
            loc = args.index(helpvalue[0])            
            args.remove(helpvalue[0])
            args.insert(loc, Messages.OPAAS_CLI_HELP_KEY)  # substituting help if entered 'h'
        
        # Bug Fix: 23525276. Honoring the -v/--version argument.
        if self.version_parser:
            versionExists = list(set(self.versionList) & set(args))
            versionValue = None
            if versionExists and len(versionExists) == 1 and len(args) >= 2:
                versionIndex = args.index(versionExists[0])
                if (versionIndex + 1) < len(args):
                    versionValue = args[versionIndex + 1]
                
        parsed, options = super().parse_known_args(args, namespace)
        
        # Bug Fix: 23525276. Honoring the -v/--version argument.
        if self.version_parser and versionExists and len(versionExists) == 1:
            if versionValue is not None:
                versionValueIndex = options.index(versionValue)
                options.insert(versionValueIndex, versionExists[0])
            else:
                options.append(versionExists[0])
        # print (parsed, options)
        return parsed, options
        
    def format_help(self):
        formatter = self._get_formatter()        
        # the list of descriptions for the commands are passed to the formatter
        formatter.command_list_description = self.command_list           
        # usage
        formatter.add_usage(self.usage, self._actions,
                            self._mutually_exclusive_groups)
        # description
        formatter.add_text(self.description)
        # positionals, optionals and user-defined groups
        for action_group in self._action_groups:
            formatter.start_section(action_group.title)
            formatter.add_text(action_group.description)            
            formatter.add_arguments(action_group._group_actions)
            formatter.end_section()
        # epilog
        formatter.add_text(self.epilog)
        # determine help from format above
        return formatter.format_help()      
    
# the below three sub classes of the main opcparser that will 
# be used for services, commands and parameters    
class OPCServiceParser(OPCParser):
    # the parser which builds the initial <service> command list
    Formatter = OPCHelpCommand  # argparse.RawTextHelpFormatter    
    def __init__ (self, description, service_commands, service_list_descriptions):
        super().__init__(formatter_class=self.Formatter,
            conflict_handler='resolve',
            description=description,
            usage=self.Usage,
            add_help=False)  # add_help=False
        # _command_list will be used by the help formatter to display the description
        # for the available services.
        self._command_list = service_list_descriptions
        self._version_parser = True  
        self._build_arguments(service_commands)
    
    @property
    def version_parser(self):
        return self._version_parser
        
    @property
    def command_list(self):
        return self._command_list
    
    @command_list.setter
    def command_list(self, value):
        self._command_list = value
        
    def _build_arguments(self, service_commands):        
        # Place to add any other commands
        self.add_argument("service", choices=CaseInsensitiveList(list(service_commands.keys())))


class OPCCommandParser(OPCParser):
    Formatter = OPCHelpCommand  # argparse.RawTextHelpFormatter    
    
    def __init__(self, command_list, service_desc, service_name):
        """
            :type command_list: dict
            :param command_list: holds the list of commands and  commandexecutor for a particular service
            
            :type service_desc: str
            :param servcie_desc: the description of the service
            
            :type servcie_name: str
            :param servcie_name: the name of the service for which the command parser is built.
        """
        Usage = Messages.OPAAS_CLI_TOP_LEVEL_SCRIPT_NAME + service_name + " <command> [parameters]"
        super().__init__(
            formatter_class=self.Formatter,
            conflict_handler='resolve',
            usage=Usage,
            description=service_desc,
            add_help=False)
        self._build(command_list)
        self._service_name = service_name
        # use this to pass the description list to the help formatter.
        self._service_commands_description = None
        # use this to pass the example if exist to the help formatter.
        self._example_for_service = None

    @property
    def command_list(self):
        return self._service_commands_description
    
    @command_list.setter 
    def command_list(self, value):
        self._service_commands_description = value 
    
    @property
    def get_examples(self):
        return self._example_for_service
    
    @get_examples.setter
    def get_examples(self, value):
        self._example_for_service = value
        
    def _build(self, command_list):
        self.add_argument('command', choices=list(command_list.keys()))
    

class OPCArgumentParser(OPCParser):       
    def __init__(self, argument_list, cmd_dict, service_name, cmd_name, cmd_list=None):
        """
           :type argument_list: dict
           :param argument_list: the argumenttypes to be added to the argument parser.
           
           :type cmd_dict: dict
           :param cmd_dict: holds the description for the specified command
           
           :type service_name: str
           :param service_name: the service name that is in scope.  
           
           :type cmd_name: str
           :param cmd_name: the cmd name that is in scope         
        """
        self.utils = Utils()
        # command_list is an optional subcommand_list.  If it's passed
        # in, then we'll update the argparse to parse a 'subcommand' argument
        # and populate the choices field with the command list keys.
        command_structure = Messages.OPAAS_CLI_TOP_LEVEL_SCRIPT_NAME + service_name + " " + cmd_name 
        # the if, is to add the parameters in the usage if it exsits in the catalog dict.
        usage = command_structure + (" [parameters]" if 'parameters' in cmd_dict else '')
        super().__init__(
            formatter_class=self.Formatter,
            usage=usage,
            description=cmd_dict['description'],
            conflict_handler='resolve',
            add_help=False)
        # register the custom type for parsing the boolean values.
        self.register('type','bool', custom_bool_type)
        # add the example and payload if present for a particular command.
        self._example_for_command = cmd_dict['example'] if 'example' in cmd_dict else None
        self._payload_for_example = cmd_dict['samplePayload'] if 'samplePayload' in cmd_dict else None        
        # TBD: if this cmd_list is needed.
        if cmd_list is None:
            cmd_list = {}
        self._command_structure = command_structure
        self._build(argument_list, cmd_list)
    
    @property
    def get_examples(self):
        return self._example_for_command
    
    @get_examples.setter
    def get_examples(self, value):
        self._example_for_command = value
    
    @property 
    def get_payload(self):
        return self._payload_for_example
    
    @get_payload.setter 
    def get_payload(self, value):
        self._payload_for_example = value 
    
    def _build(self, argument_list, cmd_list):
        for parameter_name in argument_list:
            optionArgument = argument_list[parameter_name]
            # self will this class parser
            optionArgument.add_arg_to_parser(self)
        
        # add default output format overriding at cmd level for every command:
        self.add_argument('-of','--output-format', type=str, dest=self.utils.output_format_override, metavar='',\
                           action='store', help=Messages.OPAAS_CLI_OUTPUT_FORMAT_HELP_DESC , \
                           choices = self.utils.get_output_format_values )

    def parse_known_args(self, args, namespace=None):
        if len(args) == 1 and args[0] == Messages.OPAAS_CLI_HELP_KEY:
            parsed_args = argparse.Namespace()
            parsed_args.help = Messages.OPAAS_CLI_HELP_KEY
            return parsed_args, []
        else:
            return super().parse_known_args(
                    args, namespace)
    

class OPCServiceCmdExecutor (object):
    """ the class to hold the <service> commands """
    
    def __init__ (self, service_cmd_name, opcdir, service_description):
        """
           :type service_cmd_name: str
           :param service_cmd_name: the name of the service that is keyed in.
           
           :type opcdir: str
           :param opcdir: this is the base directory from where the service json resides
           
           :type service_description: str
           :param service_description: the description that goes for each command parser.
        """
        # the service_cmd_name is the name that the CLI user types 
        # after the base psm command. for eg: psm jcs / psm setup
        self._name = service_cmd_name
        self._servicepath = opcdir 
        self._service_commands = None
        # to be passed to the OPCCommandparser for parser description
        self._service_description = service_description
        # this is used to display the description for each command 
        self._service_commands_description = OrderedDict()
        # this is to store the example for the service leve help.
        self._service_example = None
        # ths is to store the payload for the example if exists for help.
        self._service_example_payload = None
    
    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, value):
        self._name = value
    
    @property     
    def service_commands_description(self):
        return self._service_commands_description
    
    @service_commands_description.setter 
    def service_commands_description(self, value):
        self._service_commands_description = value 
    
    @property
    def service_example(self):
        return self._service_example
    
    @service_example.setter
    def service_example(self, value):
        self._service_example = value
    
    @property 
    def get_service_description(self):
        return self._service_description
    
    @property
    def service_commands(self):
        # build the service commands from <service>.json
        if self._service_commands is None:
            self._service_commands = self._build_service_cmd_list()            
        return self._service_commands
    
    def _build_service_cmd_list(self):
        # builds the list of commands associated with a particular
        # service. for eg: if the service is 'jcs', it builds all the
        # commands for jcs.
        service_commands = OrderedDict()        
        with open(self._servicepath + "/" + self.name + ".json") as jf:
            data = json.load(jf, object_pairs_hook=OrderedDict)        
        commands = data[self.name]['commands']   
        self.service_example = data[self.name]['example'] if 'example' in data[self.name] else None     
        # for each command in the specified service build the command executor 
        # which builds the parser for the parameters (options) associated with
        # that command. Passing the value, the rest of the dict for reference to 
        # opccommandexecutor.
        for command, value in commands.items():
            service_commands[command] = OPCCommandExecutor(self.name, command, value)         
            # build the description for each command to be displayed on help
            self.service_commands_description[command] = value['description']
        # add help
        service_commands[Messages.OPAAS_CLI_HELP_KEY] = OPCCustomHelpFormatter(isServiceOrCommand=False, argumentParserParameter=False)  # HELPTAG
        self.service_commands_description[Messages.OPAAS_CLI_HELP_KEY] = Messages.OPAAS_CLI_HELP_DESC  # HELPTAG
        return service_commands
    
    def __call__(self, args_extras, args_parsed):
        # to create the OPCCommand Parser by calling the create command
        # parser which is used to check the arguments for the service 
        # and then invoke the OPC Command Executor which builds the 
        # OPCArgumentParser.
        # print ("OPCServiceCommandExecutor call function")
        parser = self._create_command_parser()
        service_commands = self.service_commands 
        try:
            cmd_args_parsed, command_args_extras = parser.parse_known_args(args_extras)
            return service_commands[cmd_args_parsed.command](command_args_extras, cmd_args_parsed, service_commands)
        except argparse.ArgumentError:
            parser.print_help()                
    
    def _create_command_parser(self):
        # creates the OPCCommandParser for the list of services
        service_commands = self.service_commands  
        parser = OPCCommandParser(service_commands, self.get_service_description, self.name)
        # pass the service_command description to the parser for help formatter to use.
        parser.command_list = self.service_commands_description
        # pass the service level example to the parser for help formatter to use.
        parser.get_examples = self.service_example
        service_commands[Messages.OPAAS_CLI_HELP_KEY].parser = parser  # HELPTAG
        change_title_of_arguments(parser, 'Available commands', 'Optional arguments') 
        return parser

class OPCCommandExecutor(object):
    """ this is to call and build the options for the commands if any
        Build the ArgParser and invokes the Request builder to call
        Rest End points.
    """
    def __init__(self, service_name, cmd_name, cmd_dict):
        """
            :type service_name: str
            :param service_name: the name of the <service>
 
            :type cmd_name: str
            :param cmd_name: the name of the <command>
            
            :type cmd_dict: dict
            :param cmd_dict: holds the dict values for a given command
        """
        self._cmd_name = cmd_name
        self._service_name = service_name
        # TODO: TBD if this command_list will be used later or not
        self._command_list = None
        self._argument_list = None 
        self._arg_parameter_list = None
        # the dict for command from the json 
        self._cmd_dict = cmd_dict
    
    @property
    def cmd_name(self):
        return self._cmd_name
    
    @cmd_name.setter
    def cmd_name(self, value):
        self._cmd_name = value 
        
    @property
    def service_name(self):
        return self._service_name
    
    @service_name.setter
    def service_name(self, value):
        self._service_name = value
    
    @property 
    def command_list(self):
        return self._command_list
    
    @command_list.setter
    def command_list(self, value):
        self._command_list = value
        
    @property 
    def cmd_list_dict(self):
        return self._cmd_dict
    
    @cmd_list_dict.setter
    def cmd_list_dict(self, value):
        self._cmd_dict = value 
    
    @property 
    def arg_parameter_list(self):
        return self.arg_parameter_list
    
    @arg_parameter_list.setter 
    def arg_parameter_list(self, value):
        self._arg_parameter_list = value 
        
    @property
    def argument_list(self):
        if self._argument_list is None:
            self._argument_list = self._build_argument_list()
        return self._argument_list
    
    def _build_argument_list(self): 
        # build the list of arguments based on the command name
        # cmd_list = self._command_list[self.cmd_name]
        cmd_list_dict = self.cmd_list_dict
        argument_list = cmd_list_dict['parameters'] if 'parameters' in cmd_list_dict else None
        return argument_list
    
    def __call__(self, args_extras, args_parsed, command_list):
        # TODO: TBD if this command_list will be used later or not.
        self.command_list = command_list
        parser = self._create_argument_parser()   
        options_args_parsed, options_args_extras = parser.parse_known_args(args_extras) 
        
        # the parameter ArgParser is processed differently for Help:
        if Messages.OPAAS_CLI_HELP_KEY in options_args_parsed:
            if options_args_parsed.help == Messages.OPAAS_CLI_HELP_KEY:
                parameter_help = self._create_help(parser)
                return parameter_help(options_args_extras, options_args_parsed)
        
        if options_args_extras:
            logger.error("Unknown Argument: %s"% ' '.join(options_args_extras)) 
            raise UnknownArgumentError(arguments = ' '.join(options_args_extras), cmd_struct=parser._command_structure)
        else:
            # parse the values entered in the cmd line and build the requests
            # and format the response that gets displayed to the user.
            options_for_request_builder = RequestParamHandler(self.service_name,
                                                self.cmd_name,
                                                options_args_parsed,
                                                self._arg_parameter_list,
                                                self.cmd_list_dict['method'],
                                                self.cmd_list_dict['uri'],
                                                self.cmd_list_dict['contentType'] if 'contentType' in self.cmd_list_dict else None,
                                                self.argument_list)
            
            # Build HTTP request --> Call REST endpoint --> Process response --> Display output
            RequestExecutor(options_for_request_builder).execute_request() 
    
    def _create_help(self, parser):
        # the custom help formatter is created with a flag to indicate that 
        # it is for parameter to display the help for parameters.
        parameter_help = OPCCustomHelpFormatter(isServiceOrCommand=False, argumentParserParameter=True)
        # add the parser for formatting the help
        parameter_help.parser = parser
        return parameter_help
    
    def _create_argument_parser(self):
        # creates the parser for the optional arguments associated with
        # the specified <command>
        # the command_list: TBD if needed.
        command_list = self.command_list
        self._arg_parameter_list = self._build_parameter_list()
        parser = OPCArgumentParser(self._arg_parameter_list, self.cmd_list_dict, self.service_name, self.cmd_name) 
        change_title_of_arguments(parser, 'Required parameters', 'Optional parameters') 
        return parser
        
    def _build_parameter_list(self):
        # this is the create a list of OPCArgument object from the argument_list
        arg_parameter_list = OrderedDict()
        argument_list = self.argument_list
        if argument_list is not None:
            for parameter, value in argument_list.items():
                # Dont add the hiddenconstant parameter to the argparse. 
                # this is processed internally in handlers.
                if 'hiddenConstant' not in value:
                    # keep the arg_name and dest name the same. Look __init__ in OPCArgument for details
                    alias_name = value['alias'] if 'alias' in value else None
                    choices_list = value['choices'] if 'choices' in value else None
                    arg_parameter_list[parameter] = OPCArgument(parameter, value['type'], value['description'],
                         parameter, value['required'], 'store', alias_name, choices_list) 
        return arg_parameter_list    
