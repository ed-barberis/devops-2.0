# Copyright (c) 2015 Oracle and/or its affiliates. All rights reserved.
# created by sahit.gollapudi


import sys
import os
from argparse import ArgumentParser
import base64
import getpass 
import keyring
import requests
import pip 
import subprocess
import logging 
from pip.status_codes import (
    SUCCESS, ERROR, UNKNOWN_ERROR, VIRTUALENV_NOT_FOUND,
    PREVIOUS_BUILD_DIR_ERROR,
)
from requests.auth import _basic_auth_str
try:
    from opcservice import OPCService
    from utils import Utils, FormatText, LOGGING_CONFIG
    from exceptions import UnknownArgumentError, OpaasDownloadFileError
    from messages import Messages, ErrorMessages
except:
    from .opcservice import OPCService
    from .utils import Utils, FormatText, LOGGING_CONFIG
    from .exceptions import UnknownArgumentError, OpaasDownloadFileError
    from .messages import Messages, ErrorMessages

# Logger
logger = logging.getLogger(__name__)

class Configure(object):    
    """
       It is called on 'psm setup' to configure the credentials
    """

    def __init__(self):        
        self.utils = Utils()
        # check to maintain this list from the utils.
        self.setupList = self.utils.getsetuplist 
        self.setupTable = {}

        self.opcDir = self.utils.opcDir
        self.subOpcDir = self.utils.subOpcDir

        self.confFileName = self.utils.conf_file_name 
        self.dataFileName = self.utils.data_file_name     
        self._service = OPCService()
        
    def configureCredentials(self):
        # prompt the user with credentials
        user, passwd = self.login()
        # get the input for the other setup values.
        for inputKey in self.setupList:
            input_prompt = lambda: (input(inputKey + ": "))
            inpStr = input_prompt()
            if inputKey == self.utils._identity_domain_lbl:
                # identity domain cannot be empty.
                while not inpStr:
                    print(ErrorMessages.OPAAS_CLI_FIELD_EMPTY_ERROR_DISPLAY % inputKey)
                    inpStr = input_prompt()
                inputKey = self.utils.identity_domain
            elif inputKey == self.utils._outputFormat_lbl:
                inputKey = self.utils.output_format
                # checking for default outputformat
                if not inpStr:
                    inpStr = self.utils.default_output_value
                else:
                    if inpStr not in self.utils.get_output_format_values:
                        print(Messages.OPAAS_CLI_WARN_OUTPUT_FORMAT_MSG% self.utils.getStringFromList(self.utils.get_output_format_values))
                        inpStr = self.utils.default_output_value
            elif inputKey == self.utils.region:
                # construct the default uri.
                inputKey = self.utils.default_uri
                while True:
                    inpStr = self.getRegion(inpStr)
                    if inpStr is None:
                        print(ErrorMessages.OPAAS_CLI_REGION_ERR_DISPLAY % (self.utils.get_region_values, self.utils.region))
                    else:
                        break             
                        
            self.setupTable[inputKey] = inpStr
        
        # Defaulting the log level to Info without 
        self.setupTable[self.utils.log_level] = self.utils.default_log_level
        
        # create the directory for .opaas if it does not exists
        if not os.path.exists(self.opcDir):
            os.makedirs(self.opcDir)
        for dirname in self.subOpcDir:
            os.makedirs(self.opcDir + "/" + dirname, exist_ok=True)
                
        # validate the user credentials
        urlHostName = self.setupTable[self.utils.default_uri]
        identityDomain = self.setupTable[self.utils.identity_domain]
        validatationResult, user, passwd = self.getValidationCode(user, passwd, identityDomain, urlHostName)  
        
        # to get the value of the client_version if setup is run multiple times
        client_version = self.utils.get_existing_cli_version()
        
        # if validation is successful then write conf file. else return
        if validatationResult:
            # if successfull add the token to the keyring
            token = self.createToken(user, passwd) 
            # add the user to the config file: open with append mode or write new mode.
            mode = 'w' if os.path.exists(self.confFileName) else 'a'
            with open(self.confFileName, mode) as f:
                f.write("%s=%s\n" % (self.utils.username, user))
                for key, value in self.setupTable.items():
                    f.write("%s=%s\n" % (key, value))                
            f.close()
            # add the token to the keyring
            keyring.set_password(self.utils.cli_keyring_name, user, token) 
        else:
            return
        
        # get the list of service catalogs once everything is fixed.
        # True is when the setup is run explicitly, 
        # client_version for conf file update
        self._service.callRestApiGetServiceTypes(True, client_version)
     
    def login(self):
        # prompts the user to enter the credentials.
        userPrompt = lambda: (input("%s: " % self.utils.username_lbl))
        user = userPrompt()
        # username cannot be empty. 
        while not user:
            print(ErrorMessages.OPAAS_CLI_FIELD_EMPTY_ERROR_DISPLAY % self.utils.username_lbl)  # user = getpass.getuser()
            user = userPrompt()
        pprompt = lambda: (getpass.getpass('%s: ' % self.utils._pwd_lbl), getpass.getpass(Messages.OPAAS_CLI_RETYPE_PWD % self.utils._pwd_lbl))
        passwd, passwd2 = pprompt()
        # Passwords cannot be empty and passwords should match all the time.
        while passwd != passwd2 or not passwd:
            if not passwd or not passwd2:
                print(ErrorMessages.OPAAS_CLI_FIELD_EMPTY_ERROR_DISPLAY % self.utils._pwd_lbl)
            else:
                print(ErrorMessages.OPAAS_CLI_PWD_MATCH_ERROR_DISPLAY)
            passwd, passwd2 = pprompt()            
        return user, passwd 

    # Get SM URL from 'Region [us]' input value entered in psm setup.
    def getRegion(self, inpStr=None):
        # Invoke cmd prompt for Region if input is None
        if inpStr is None:
            inpStr = input(self.utils.region + ": ")
        
        if not inpStr:
            # the default will be US.
            inpStr = self.utils.get_public_domain_url('us')
        else:
            inpStr = self.utils.get_public_domain_url(inpStr)
        
        self.setupTable[self.utils.default_uri] = inpStr
        
        return inpStr   
    
    def checkCredentials(self, user, passwd, identityDomain, urlHostName):
        if user and passwd:
            token = self.createToken(user, passwd)
            # return true if validation successful 
            return self._service.checkCredentials(token, identityDomain, urlHostName)  
    
    def getValidationCode(self, user, passwd, identityDomain, urlHostName):
        # check for valid credentials at this point.
        validationCode = self.checkCredentials(user, passwd, identityDomain, urlHostName)
        if validationCode == True:
            return True, user, passwd
        else: 
            if validationCode == 400:
                # bad request error
                self._display_error(ErrorMessages.OPAAS_CLI_DEFAULT_URI_ERROR_DISPLAY)
            elif validationCode in (404, 111):
                # invalid URL
                self._display_error(ErrorMessages.OPAAS_CLI_GENERIC_SETUP_VALUES_ERR_DISPLAY % (self.utils.username_lbl, self.utils._pwd_lbl, \
                                                                                                self.utils._identity_domain_lbl, self.utils.region))
            elif validationCode == 502:
                # invalid host or host not resolvable
                self._display_error(ErrorMessages.OPAAS_CLI_DNS_ERROR_DISPLAY % (urlHostName, self.utils.region))
            elif validationCode == 401:
                # authorization error
                print(ErrorMessages.OPAAS_CLI_UNAME_PWD_ERR_DISPLAY)
                user, passwd = self.login()
                self.getValidationCode(user, passwd, identityDomain, urlHostName)
                return True, user, passwd 
            elif validationCode == 403:
                # Identity domain error
                self._display_error(ErrorMessages.OPAAS_CLI_INVALID_IDENTITY_DOMAIN_ERR_DISPLAY % (identityDomain, self.utils._identity_domain_lbl))
            elif validationCode == False:
                self._display_error(ErrorMessages.OPAAS_CLI_GENERIC_ERR_DISPLAY) 
            
            # return false                
            return False, user, passwd
   
    def _display_error(self, msg):
        print('\n--------------------------------------------------------------------------------') 
        print(msg)
        logger.error(msg)
        print('--------------------------------------------------------------------------------') 


    def createToken(self, username, password):
        """
            this is used to create the http basic auth token. for the rest calls.
        """
        basicAuthToken = _basic_auth_str(username, password)
        return basicAuthToken


class SetupParser(object):
    """
    The setup parser which handles the setup functions.
    """
    def __init__(self, service_name, service_description):
        self.service_name = service_name
        self.service_description = service_description
        self._configure = Configure()
    
    def __call__(self, args_extras, args_parsed):
        if Messages.OPAAS_CLI_HELP_KEY in args_extras:
            self._display_help()        
        elif args_extras:
            raise UnknownArgumentError(arguments=' '.join(args_extras), cmd_struct=Messages.OPAAS_CLI_TOP_LEVEL_SCRIPT_NAME + 'setup')
        else:    
            self._configure.configureCredentials()
    
    def _display_help(self):
        script_dir = os.path.dirname(__file__)
        fileName = "setuphelp.txt"
        rel_path = os.path.join(script_dir, fileName)
        if os.path.exists(rel_path):
            with open(rel_path, "r") as f:
                print(f.read())
        else: 
            logger.error(ErrorMessages.OPAAS_CLI_SETUP_HELP_ERROR)
            print(ErrorMessages.OPAAS_CLI_SETUP_GENERIC_DISPLAY)
   
class OpaasSync(object):
    """
    This upgrades to the latest client on psm upgrade. 
    """
    def __init__(self, service_name, service_description):
        self.service_name = service_name
        self.service_description = service_description
        self._opcservice = OPCService()
        self._utils = Utils()
    
    def __call__(self, args_extras, args_parsed):
        if Messages.OPAAS_CLI_HELP_KEY in args_extras:
            self._display_help()
        elif args_extras:
            logger.error(ErrorMessages.OPAAS_CLI_UPGRADE_UNKNOWN_ARGS_ERROR, ' '.join(args_extras))
            raise UnknownArgumentError(arguments=' '.join(args_extras), cmd_struct=Messages.OPAAS_CLI_TOP_LEVEL_SCRIPT_NAME + 'upgrade')
        else:
            # check the version and determine whether to upgrade or not.
            self._check_version_and_upgrade()
            
    def _display_help(self):
        script_dir = os.path.dirname(__file__)
        fileName = "upgradehelp.txt"
        rel_path = os.path.join(script_dir, fileName)
        if os.path.exists(rel_path):
            with open(rel_path, "r") as f:
                print(f.read())
        else: 
            logger.error(ErrorMessages.OPAAS_CLI_UPGRADE_HELP_ERROR)
            print(ErrorMessages.OPAAS_CLI_UPGRADE_GENERIC_DISPLAY)
    
    def _install(self, package):
        # call the pip main to run the install for the upgrade command.
        return_code = pip.main(['install', '-U', package])
        
        if return_code == SUCCESS:
            logging.config.dictConfig(LOGGING_CONFIG)
            logger.info(Messages.OPAAS_CLI_UPGRADE_LOG_SUCCESS)
            return True
        elif return_code == ERROR:
            logger.error(ErrorMessages.OPAAS_CLI_UPGRADE_LOG_ERROR)
            return False
        elif return_code == UNKNOWN_ERROR:
            logger.error(ErrorMessages.OPAAS_CLI_UPGRADE_LOG_UNKOWN_ERROR)
            return False
        elif return_code == PREVIOUS_BUILD_DIR_ERROR:
            logger.error(ErrorMessages.OPAAS_CLI_UPGRADE_LOG_BUILD_ERROR)
            return False

    def _install_root(self, package):
        logger.info(Messages.OPAAS_CLI_UPGRADE_SUDO_PROMPT)
        sys.stdout.write(Messages.OPAAS_CLI_UPGRADE_SUDO_PROMPT)        
        success = True
        sudo_opts = '-HE' if self._utils.isMac() else '-H'
        p = subprocess.Popen(['sudo', sudo_opts, 'pip', 'install', '-U', package], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = p.communicate()
        # seperate check for command not found for pip, install with pip3
        # 1 is to determine its always true.
        err_cmd_not_found_code = 1
        if err:
            err_cmd_not_found_code = self._check_err_msg(err)
        
        # check for error_code. if 2, then re-run the upgrade with pip3.
        if err_cmd_not_found_code == 2:
            # rerun the upgrade using pip3.
            p2 = subprocess.Popen(['sudo', sudo_opts, 'pip3', 'install', '-U', package], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            out, err = p2.communicate()            
            # check for err and success msgs. if error code is 1, then its true implicitly
            if err:
                err_code = self._check_err_msg(err, upgrade_using_pip=False)
                if err_code == 3 or err_code == 2:
                    success = False
      
        # check for other exceptions if failed.    
        elif err_cmd_not_found_code == 3:
            success = False   
        
        # if no exception display the output for the upgrade using pip.
        if out:
            output = out.splitlines()
            for msg in output:
                sys.stdout.write('%s\n' % msg.decode('ascii'))

        if success:
            logging.config.dictConfig(LOGGING_CONFIG)
            logger.info(Messages.OPAAS_CLI_UPGRADE_LOG_SUCCESS)
        return success
    
    def _check_err_msg(self, err, upgrade_using_pip=True):
        # success codes - 1 : success. 2 : pip command not found. 3 : Other exceptions
        success = 1;
        errMsg = err.splitlines()
        for msg in errMsg:
            decode_msg = msg.decode('ascii')
            # to figure out if there was any exception while upgrade.
            #if 'Exception:' in decode_msg or 'Exception' in decode_msg or 'Traceback' in decode_msg:
            if 'command not found' in decode_msg:
                if upgrade_using_pip:
                    logger.error(ErrorMessages.OPAAS_CLI_UPGRADE_PIP_RETRY_ERROR % decode_msg)
                    success = 2
                    break
                else:
                    logger.error(ErrorMessages.OPAAS_CLI_UPGRADE_PIP_NOT_FOUND_ERROR)
                    sys.stderr.write(ErrorMessages.OPAAS_CLI_UPGRADE_PIP_NOT_FOUND_ERROR)
            if any(error_msg in decode_msg.lower() for error_msg in ['exception:', 'exception', 'traceback', 'command not found', \
                                                                     'invalid password', 'incorrect password']): 
                logger.error(ErrorMessages.OPAAS_CLI_UPGRADE_PIP_ERROR % decode_msg)
                success=3
            sys.stderr.write('%s\n' % decode_msg)
        return success                    
    
    def _check_version_and_upgrade(self):
        # update the cli_artifacts_version in the conf.
        defaultUri = self._utils.getValueFromConfigFile(self._utils.default_uri)
        cli_artifacts_version = self._opcservice.checkCredentials(self._utils.getAuthToken(), self._utils.getValueFromConfigFile(self._utils.identity_domain), \
                                                                  defaultUri, return_cli_artifacts_upgrade=True)
        
        if cli_artifacts_version is not None and self._utils._version_split_token in str(cli_artifacts_version):
            existing_client_version, existing_last_updated_time, existing_catalog_build_version = self._utils.get_existing_cli_artifacts_versions()
            new_client_version, new_last_updated_time, catalog_build_version = self._utils.parse_cli_artifacts_versions(cli_artifacts_version)
              
            # check if the client versions are the same, if same there is no need to upgrade.
            if (new_client_version is not None and existing_last_updated_time is not None) and \
                              (self._utils.checkVersionEquality(existing_client_version, new_client_version) or \
                              self._utils.checkVersionGreaterThan(existing_client_version, new_client_version)):
                logger.info(Messages.OPAAS_CLI_LATEST_VERSION_EXISTS)
                sys.stdout.write('%s: %s\n' % (FormatText.bold(Messages.OPAAS_CLI_INFO_MSG), Messages.OPAAS_CLI_LATEST_VERSION_EXISTS))
                return
            
            # upgrade to the latest.
            success = self._upgrade_to_latest(existing_client_version, new_client_version)
        
            # write the value to the conf
            if success:
                self._utils.writeValueToConfigFile(self._utils.build_version_key, \
                    self._utils.concat_cli_artifacts_versions(new_client_version.strip(), \
                                                               existing_last_updated_time.strip(), \
                                                               existing_catalog_build_version))
        else:
            if cli_artifacts_version is None:
                logger.error(ErrorMessages.OPAAS_CLI_NO_VERSION_FOUND_ERROR)
            elif cli_artifacts_version == 502:
                # invalid host or host not resolvable
                logger.error(ErrorMessages.OPAAS_CLI_UPGRADE_DNS_ERROR_DISPLAY % defaultUri)
                sys.stderr.write(ErrorMessages.OPAAS_CLI_UPGRADE_DNS_ERROR_DISPLAY % defaultUri)
            else:
                logger.error(ErrorMessages.OPAAS_CLI_UPGRADE_GENERIC_ERROR % (cli_artifacts_version))
            
            logger.info(ErrorMessages.OPAAS_CLI_UPGRADE_FAILED_ERR_DISPLAY)    
            sys.stdout.write(ErrorMessages.OPAAS_CLI_UPGRADE_FAILED_ERR_DISPLAY)        
                
    
    def _upgrade_to_latest(self, existing_client_version, new_client_version):
        logger.info(Messages.OPAAS_CLI_UPGRADE_DOWNLOAD_KIT % new_client_version)
        sys.stdout.write(Messages.OPAAS_CLI_UPGRADE_DOWNLOAD_KIT % new_client_version)
        tmp_file_loc = self._opcservice.callRestApiToDownloadClient()
        if tmp_file_loc is None:
            logger.error(ErrorMessages.OPAAS_CLI_UPGRADE_DOWNLOAD_KIT_LOCATION_ERROR)
            raise OpaasDownloadFileError()
        try:
            logger.info(Messages.OPAAS_CLI_UPGRADE_DOWNLOAD_KIT_UPGRADING % (existing_client_version, new_client_version))            
            sys.stdout.write(Messages.OPAAS_CLI_UPGRADE_DOWNLOAD_KIT_UPGRADING % (existing_client_version, new_client_version))
            
            # upgrade the clientkit.    
            if self._utils.isWindows():
                return self._install(tmp_file_loc)
            else:
               return self._install_root(tmp_file_loc)  
           
            return False      
        finally:
            # remove the downloaded kit
            if os.path.exists(tmp_file_loc):
                os.remove(tmp_file_loc)
                logger.info(Messages.OPAAS_CLI_UPGRADE_CLEANING_UP)
                sys.stdout.write(Messages.OPAAS_CLI_UPGRADE_CLEANING_UP)


class OpaasLogLevel(object):
    """
    Logging level for PSM cli.
    """
    def __init__(self, service_name, service_description):
        self.service_name = service_name
        self.service_description = service_description
        self._utils = Utils()
    
    def __call__(self, args_extras, args_parsed):
        if Messages.OPAAS_CLI_HELP_KEY in args_extras:
            self._display_help()
        else:
            current_level = self._utils.getValueFromConfigFile(self._utils.log_level).lower()        
            if len(args_extras) == 0:
                sys.stdout.write(Messages.OPAAS_CLI_INFO_CURRENT_LOG_LEVEL_MSG % current_level)        
            elif len(args_extras) == 2 and args_extras[0] in self._utils.log_level_argument:
                   level = args_extras[1]
                   if level not in self._utils.get_available_log_levels:
                        sys.stdout.write(Messages.OPAAS_CLI_WARN_LOG_LEVEL_MSG % self._utils.get_available_log_levels)
                   else:
                       if  current_level != level.lower():
                           self._utils.writeValueToConfigFile(self._utils.log_level, level)
                           logger.info(Messages.OPAAS_CLI_INFO_LOG_LEVEL_UPDATE_MSG % level)
                           sys.stdout.write(Messages.OPAAS_CLI_INFO_LOG_LEVEL_UPDATE_MSG % level)
            else:
                sys.stdout.write(ErrorMessages.OPAAS_CLI_LOG_LEVEL_ERROR)    
   
    def _display_help(self):
        script_dir = os.path.dirname(__file__)
        fileName = "loghelp.txt"
        rel_path = os.path.join(script_dir, fileName)
        if os.path.exists(rel_path):
            with open(rel_path, "r") as f:
                print(f.read())
        else: 
            logger.error(ErrorMessages.OPAAS_CLI_LOG_LEVEL_HELP_ERROR)
            sys.stdout.write(ErrorMessages.OPAAS_CLI_LOG_LEVEL_GENERIC_DISPLAY)     
    
