# Copyright (c) 2015 Oracle and/or its affiliates. All rights reserved.
# created by sahit.gollapudi

import json
from collections import OrderedDict
try:
    from utils import Utils
except:
    from .utils import Utils

#======= CLASSES =================================================================


class OutputFormatter(object):
    """
       a generic formatter which needs to implemented in order to get the 
       desired output format specified in the conf file.
    """
    def __init__(self, content):
        self._content = content
        self._utils = Utils()
    
    @property
    def content(self):
        return self._content
    
    def _format_content(self):
        raise NotImplementedError("Not Implemented")
    
class JSONFormatter(OutputFormatter):
    
    def _format_content(self):
        data = self.content
        # commented the sort keys. To maintain the order from the REST response
        json_formatted = json.dumps(data, indent=4, separators=(',',':')) #,sort_keys=True)
        return json_formatted
    
class TextFormatter(OutputFormatter):
    
    def _format_content(self):
        # to replace any string if it has \r\n for linux
        data = self.content.replace('\r','') if self._utils.isLinux() else self.content
        return data 
    
class HtmlFormatter(OutputFormatter):
    def _format_content(self):
        data = self.content
        formatted_html = JsonToHtml().convert(json = data)
        return formatted_html if formatted_html is not None else data


class JsonToHtml(object):

    def convert(self, **args):
        '''
        convert json Object to HTML Table format
        '''
        # table attributes such as class
        # eg: table_attributes = "class = 'sortable table table-condensed table-bordered table-hover'
        global table_attributes
        table_attributes = ''
        
        if 'table_attributes' in args:
            table_attributes = args['table_attributes']
        else:
            # by default HTML table border
            table_attributes = 'border="1"'

        if 'json' in args:
            self.json_input = args['json']
            try:
                json.loads(self.json_input)
            except:
                self.json_input = json.dumps(self.json_input)
        else:
            raise Exception('Can\'t convert NULL!')

        ordered_json = json.loads(self.json_input, object_pairs_hook=OrderedDict)
        
        # Fix for BUG 22506411 and 22760139: Added html parsing for List type Jsons.
        if not isinstance(ordered_json,(dict,list)):
            return ordered_json 
        
        # To sort the values in the json before converting to html.
        # commenting the HTML sorting too.
        #try:
        #    sorted_json = json.dumps(ordered_json, sort_keys=True)
        #    ordered_json = json.loads(sorted_json, object_pairs_hook=OrderedDict)
        #except:
        #    pass

        # this is invoked only if the response content is a type of dict, json or list. 
        return self.iterJson(ordered_json)

    def columnHeadersFromListOfDicts(self, ordered_json):
        '''
        If suppose some key has array of objects and all the keys are same,
        instead of creating a new row for each such entry, club those values,
        thus it makes more sense and more readable code.
        @example:
            jsonObject = {"sampleData": [ {"a":1, "b":2, "c":3}, {"a":5, "b":6, "c":7} ] }
            OUTPUT:
                <table border="1"><tr><th>1</th><td><table border="1"><tr><th>a</th><th>c</th><th>b</th></tr><tr><td>1</td>
                <td>3</td><td>2</td></tr><tr><td>5</td><td>7</td><td>6</td></tr></table></td></tr></table>
        '''

        if len(ordered_json) < 2:
            return None
        if not isinstance(ordered_json[0],dict):
            return None

        column_headers = ordered_json[0].keys()

        for entry in ordered_json:
            if not isinstance(entry,dict):
                return None
            if len(entry.keys()) != len(column_headers):
                return None
            for header in column_headers:
                if not header in entry:
                    return None
        return column_headers

    def iterJson(self, ordered_json):
        '''
        Iterate over the JSON and process it to generate the super awesome HTML Table format
        '''
        def markup(entry, parent_is_list = False):
            '''
            Check for each value corresponding to its key and return accordingly
            '''
            if(isinstance(entry,str)):
                return str(entry)
            if(isinstance(entry,int) or isinstance(entry,float)):
                return str(entry)
            if(parent_is_list and isinstance(entry,list)==True):
                #list of lists are not accepted
                return ''
            if(isinstance(entry,list)==True) and len(entry) == 0:
                return ''
            if(isinstance(entry,list)==True):
                return '<ul><li>' + '</li><p/><li>'.join([markup(child, parent_is_list=True) for child in entry]) + '</li><p/></ul>'
            if(isinstance(entry,dict)==True):
                return self.iterJson(entry)

            #safety: don't do recursion over anything that we don't know about - items() will most probably fail
            return ''
        
        def buildHtml(json_value, htmlOutput):
            for k,v in json_value.items():
                htmlOutput = htmlOutput + '<tr>'
                htmlOutput = htmlOutput + '<th>'+ markup(k) +'</th>'
    
                if (v == None):
                    v = str("")
                if(isinstance(v,list)):
                    column_headers = self.columnHeadersFromListOfDicts(v)
                    if column_headers != None:
                        htmlOutput = htmlOutput + '<td>'
                        htmlOutput = htmlOutput + table_init_markup
                        htmlOutput = htmlOutput + '<tr><th>' + '</th><th>'.join(column_headers) + '</th></tr>'
                        for list_entry in v:
                            htmlOutput = htmlOutput + '<tr><td>' + '</td><td>'.join([markup(list_entry[column_header]) for column_header in column_headers]) + '</td></tr>'
                        htmlOutput = htmlOutput + '</table>'
                        htmlOutput = htmlOutput + '</td>'
                        htmlOutput = htmlOutput + '</tr>'
                        continue
                htmlOutput = htmlOutput + '<td>' + markup(v) + '</td>'
                htmlOutput = htmlOutput + '</tr>'      
            return htmlOutput
        
        htmlOutput = ''

        global table_attributes
        table_init_markup = "<table %s>" %(table_attributes)
        htmlOutput = htmlOutput + table_init_markup
        
        # Fix: Bug 22760139: added support for converting a list type json into html.
        if isinstance(ordered_json, list):
            for item in ordered_json:
                if (isinstance(item, dict)):
                    htmlOutput = htmlOutput + buildHtml(item, htmlOutput)
        else:
            htmlOutput = htmlOutput + buildHtml(ordered_json, htmlOutput)
                
        htmlOutput = htmlOutput + '</table>'
        return htmlOutput
        
        

#======= CONSTANTS ===============================================================
OUTPUT_FORMATTER = {
    'json' : JSONFormatter,
    'text' : TextFormatter,
    'html' : HtmlFormatter,
}
