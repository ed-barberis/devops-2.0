# Copyright (c) 2015 Oracle and/or its affiliates. All rights reserved.
# A generic class where all the exception types are documented.
# created by sahit.gollapudi

class OPCError(Exception):    
    
    errMsg = 'An unspecified error occurred.'

    def __init__(self, **args):
        msg = self.errMsg.format(**args)
        Exception.__init__(self, msg)

class ResponseNullError(OPCError):
    
    errMsg = 'Error while trying to attempt an HTTP call.'
    
class UnknownArgumentError(OPCError):
    # this is called when an unknown argument is specified in the cmd line.
    errMsg = "Unknown argument {arguments}. Please execute '{cmd_struct} h' for allowed arguments."
    
class DataNotFoundError(OPCError):
    # if data not found in the cloud.
    errMsg = "No data found."

class OpaasConfigError(OPCError):
    # if any data is missing in the config file.
    errMsg = "Please configure the psm client using the command 'psm setup'."
    
class OpaasDownloadFileError(OPCError):
    # if the downloaded file is None.
    errMsg = "Error while trying to Download the latest version."
